sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/m/MessageToast"
], function (Controller, JSONModel, MessageBox, MessageToast) {
    "use strict";

    return Controller.extend("userform.controller.UserForm", {
        onInit: function () {
            this._initAddressCache();
            this._initModels();
        },

        _initModels: function () {
            // Address model
            this.getView().setModel(new JSONModel({
                suggestions: [],
                selectedAddress: {
                    latitude: "",
                    longitude: "",
                    displayName: ""
                }
            }), "address");

            // Main form model with default values
            this.getView().setModel(new JSONModel({
                Firstname: "",
                Lastname: "",
                ContractType: "fixed",
                FixedEnergyPrice: null,
                PanelsAmount: 1,
                ModulesPower: 300,
                PanelAngle: 30,
                PanelAzimuth: 180,
                InstallationDate: null
            }));
        },

        _initAddressCache: function () {
            this._addressCache = this._addressCache || new Map();
        },

        onContractTypeChange: function (oEvent) {
            const sSelectedKey = oEvent.getParameter("selectedIndex") === 0 ? "fixed" : "variable";
            this.getView().getModel().setProperty("/ContractType", sSelectedKey);

            if (sSelectedKey === "variable") {
                this.getView().getModel().setProperty("/FixedEnergyPrice", null);
            }
        },

        validateEnergyPrice: function (oEvent) {
            const sValue = oEvent.getParameter("value");
            const oInput = oEvent.getSource();
            let sState = "None";
            let sStateText = "";

            if (sValue) {
                if (isNaN(parseFloat(sValue))) {
                    sState = "Error";
                    sStateText = "Voer een geldig getal in";
                } else if (parseFloat(sValue) <= 0) {
                    sState = "Error";
                    sStateText = "Prijs moet groter zijn dan 0";
                }
            } else if (this.getView().getModel().getProperty("/ContractType") === "fixed") {
                sState = "Error";
                sStateText = "Dit veld is verplicht voor fixed contract";
            }

            oInput.setValueState(sState);
            oInput.setValueStateText(sStateText);
        },

        onSuggestAddress: async function (oEvent) {
            const sValue = (oEvent.getParameter("suggestValue") || "").trim();
            const oAddressModel = this.getView().getModel("address");

            if (sValue.length < 2) {
                oAddressModel.setProperty("/suggestions", []);
                return;
            }

            if (this._addressCache.has(sValue)) {
                oAddressModel.setProperty("/suggestions", this._addressCache.get(sValue));
                return;
            }

            if (this._suggestionAbortController) {
                this._suggestionAbortController.abort();
            }
            this._suggestionAbortController = new AbortController();

            try {
                const sQuery = encodeURIComponent(sValue);
                const response = await fetch(
                    `https://nominatim.openstreetmap.org/search?q=${sQuery}&format=json&addressdetails=1&countrycodes=be&limit=5`,
                    {
                        headers: { "User-Agent": "EnergyManagementSystem/1.0" },
                        signal: this._suggestionAbortController.signal
                    }
                );

                if (!response.ok) throw new Error("Network error");

                const aData = await response.json();
                const aSuggestions = aData.map(item => ({
                    description: this._formatAddress(item),
                    lat: item.lat,
                    lon: item.lon
                }));

                this._addressCache.set(sValue, aSuggestions);
                oAddressModel.setProperty("/suggestions", aSuggestions);
            } catch (error) {
                if (error.name !== 'AbortError') {
                    console.error("Address suggestion error:", error);
                    MessageToast.show("Adres suggesties konden niet worden opgehaald");
                }
            }
        },

        _formatAddress: function (oItem) {
            const oAddr = oItem.address || {};
            const aParts = [
                [oAddr.road, oAddr.house_number].filter(Boolean).join(" "),
                oAddr.postcode,
                oAddr.city
            ].filter(Boolean);


            return aParts.length > 0 ? aParts.join(", ") : oItem.display_name;
        },

        onAddressSelected: function (oEvent) {
            const oSelectedItem = oEvent.getParameter("selectedItem");
            if (!oSelectedItem) return;

            const oContext = oSelectedItem.getBindingContext("address");
            if (!oContext) return;

            const oSelected = oContext.getObject();
            const oAddressModel = this.getView().getModel("address");

            // Parse the coordinates as floats and round to 6 decimal places
            const roundedLat = parseFloat(parseFloat(oSelected.lat).toFixed(6));
            const roundedLon = parseFloat(parseFloat(oSelected.lon).toFixed(6));

            oAddressModel.setProperty("/selectedAddress", {
                latitude: roundedLat,
                longitude: roundedLon,
                displayName: oSelected.description
            });
        },


        onSavePress: function() {
            const oView = this.getView();
            const oFormModel = oView.getModel();
            const oAddressModel = oView.getModel("address");
        
            if (!this._validateForm()) {
                MessageToast.show("Vul alle verplichte velden in");
                return;
            }
        
            oView.setBusy(true);
        
            // Prepare data for CAP service with proper data types
            const oFormData = {/*
                Firstname: oFormModel.getProperty("/Firstname"),
                Lastname: oFormModel.getProperty("/Lastname"),
                ContractType: oFormModel.getProperty("/ContractType"),*/
                FixedEnergyPrice: parseFloat(oFormModel.getProperty("/FixedEnergyPrice")) || null,
                PanelsAmount: parseInt(oFormModel.getProperty("/PanelsAmount"), 10),
                ModulePower: parseInt(oFormModel.getProperty("/ModulesPower"), 10),
                PanelAngle: parseInt(oFormModel.getProperty("/PanelAngle"), 10),
                PanelAzimuth: parseInt(oFormModel.getProperty("/PanelAzimuth"), 10),
                Latitude: parseFloat(oAddressModel.getProperty("/selectedAddress/latitude")),
                Longitude: parseFloat(oAddressModel.getProperty("/selectedAddress/longitude")),
                DisplayName: oAddressModel.getProperty("/selectedAddress/displayName")
            };
        
            console.log("Submitting data:", JSON.stringify(oFormData));
        
            // Make sure we're calling the action endpoint, not the entity set
            $.ajax({
                url: "/odata/v4/energy/SolarConfigurations",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({
                    PanelAmount: parseInt(oFormModel.getProperty("/PanelsAmount"), 10),
                    ModulePower: parseInt(oFormModel.getProperty("/ModulesPower"), 10),
                    PanelAngle: parseInt(oFormModel.getProperty("/PanelAngle"), 10),
                    PanelAzimuth: parseInt(oFormModel.getProperty("/PanelAzimuth"), 10),
                    Latitude: parseFloat(oAddressModel.getProperty("/selectedAddress/latitude")),
                    Longitude: parseFloat(oAddressModel.getProperty("/selectedAddress/longitude")),
                    Location: oAddressModel.getProperty("/selectedAddress/displayName")
                }),
                success: function() {
                    MessageToast.show("Configuratie succesvol opgeslagen");
                    oView.setBusy(false);
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.error("Save error:", jqXHR);
                    
                    let errorMessage = "Onbekende fout";
                    try {
                        const errorResponse = JSON.parse(jqXHR.responseText);
                        errorMessage = errorResponse.error.message || errorThrown || "Onbekende fout";
                    } catch (e) {
                        errorMessage = jqXHR.responseText || errorThrown || "Onbekende fout";
                    }
                    
                    MessageBox.error("Opslaan mislukt: " + errorMessage);
                    oView.setBusy(false);
                }
            });
        },

        _validateForm: function () {
            let isValid = true;
            const oFormModel = this.getView().getModel();

            // Helper function to safely set value state
            const setInputState = (sId, sState, sStateText) => {
                const oInput = this.byId(sId);
                if (oInput) {
                    oInput.setValueState(sState);
                    if (sStateText) oInput.setValueStateText(sStateText);
                }
            };

            // Validate required fields
            ["Firstname", "Lastname"].forEach(sField => {
                const sValue = oFormModel.getProperty(`/${sField}`);
                const sInputId = `${sField.toLowerCase()}Input`;

                if (!sValue || sValue.trim() === "") {
                    setInputState(sInputId, "Error", "Dit veld is verplicht");
                    isValid = false;
                } else {
                    setInputState(sInputId, "None");
                }
            });

            // Validate energy price for fixed contracts
            if (oFormModel.getProperty("/ContractType") === "fixed") {
                const fPrice = oFormModel.getProperty("/FixedEnergyPrice");

                if (!fPrice || isNaN(fPrice) || fPrice <= 0) {
                    setInputState("energyPriceInput", "Error",
                        isNaN(fPrice) ? "Voer een geldig getal in" : "Prijs moet groter zijn dan 0");
                    isValid = false;
                } else {
                    setInputState("energyPriceInput", "None");
                }
            }

            // Validate address
            const sAddress = this.getView().getModel("address").getProperty("/selectedAddress/displayName");
            if (!sAddress || sAddress.trim() === "") {
                setInputState("addressInput", "Error", "Selecteer een adres");
                isValid = false;
            } else {
                setInputState("addressInput", "None");
            }

            return isValid;
        }
    });
});